package br.com.fiap.winery;

public class ApplicationClient1 {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}